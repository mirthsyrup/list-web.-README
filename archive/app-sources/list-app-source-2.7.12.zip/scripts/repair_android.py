"""Preserve 2.7.1 payload; repair manifest and APK packaging before signing."""
import io
import struct
import sys
import zipfile
from pathlib import Path


def repair_manifest(raw):
    data = bytearray(raw)
    strings = []
    offset = 8
    changed = []
    while offset < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, offset)
        assert size >= header and offset + size <= len(data)
        if kind == 1:
            count, _, flags, start, _ = struct.unpack_from('<IIIII', data, offset + 8)
            for i in range(count):
                p = offset + start + struct.unpack_from('<I', data, offset + header + i * 4)[0]
                if flags & 0x100:
                    def length(pos):
                        n = data[pos]
                        return (((n & 0x7f) << 8) | data[pos + 1], pos + 2) if n & 0x80 else (n, pos + 1)
                    _, p = length(p)
                    n, p = length(p)
                    strings.append(bytes(data[p:p+n]).decode('utf-8'))
                else:
                    n = struct.unpack_from('<H', data, p)[0]
                    p += 2
                    if n & 0x8000:
                        n = ((n & 0x7fff) << 16) | struct.unpack_from('<H', data, p)[0]
                        p += 2
                    strings.append(bytes(data[p:p+n*2]).decode('utf-16le'))
        elif kind == 0x102:
            ext = offset + header
            _, name, attr_start, attr_size, count = struct.unpack_from('<IIHHH', data, ext)
            element = strings[name]
            for i in range(count):
                p = ext + attr_start + i * attr_size
                ns, name, raw_index, value_size, zero, value_type, value = struct.unpack_from('<IIIHBBI', data, p)
                attribute = strings[name]
                replacement = {('uses-sdk', 'targetSdkVersion'): 34,
                               ('manifest', 'versionCode'): 280}.get((element, attribute))
                if replacement is not None:
                    assert value_type == 0x10 and raw_index == 0xffffffff
                    struct.pack_into('<I', data, p + 16, replacement)
                    changed.append((element, attribute, value, replacement))
        offset += size
    assert offset == len(data) and len(changed) == 2, changed
    return bytes(data), changed


def repair(source, destination):
    buffer = io.BytesIO()
    with zipfile.ZipFile(source) as old, zipfile.ZipFile(buffer, 'w') as new:
        for old_item in old.infolist():
            if old_item.filename.startswith('META-INF/'):
                continue
            payload = old.read(old_item)
            if old_item.filename == 'AndroidManifest.xml':
                payload, changes = repair_manifest(payload)
                print(changes)
            item = zipfile.ZipInfo(old_item.filename, old_item.date_time)
            item.compress_type = old_item.compress_type
            item.external_attr = old_item.external_attr
            if item.filename == 'resources.arsc':
                item.compress_type = zipfile.ZIP_STORED
            if item.compress_type == zipfile.ZIP_STORED:
                base = new.fp.tell() + 30 + len(item.filename.encode('utf-8'))
                padding = (4 - (base + 4) % 4) % 4
                item.extra = struct.pack('<HH', 0xffff, padding) + bytes(padding)
            new.writestr(item, payload)
    Path(destination).write_bytes(buffer.getvalue())


if __name__ == '__main__':
    repair(*sys.argv[1:])
