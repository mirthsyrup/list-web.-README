from pathlib import Path
import io,zipfile,struct,plistlib
root=Path(__file__).resolve().parents[1];base=root.parent/'release279/project/out';out=root/'out';out.mkdir(exist_ok=True)

def manifest(data):
 chunks=[];strings=[];o=8
 while o<len(data):
  typ,h,size=struct.unpack_from('<HHI',data,o);raw=bytearray(data[o:o+size])
  if typ==1:
   count,styles,flags,start,styles_start=struct.unpack_from('<IIIII',raw,8);assert styles==0 and not flags&256
   for i in range(count):
    p=start+struct.unpack_from('<I',raw,h+i*4)[0];n=struct.unpack_from('<H',raw,p)[0];assert n<32768
    strings.append(bytes(raw[p+2:p+2+n*2]).decode('utf-16le'))
   assert '2.7.9' in strings;strings[strings.index('2.7.9')]='2.7.12'
   payload=bytearray();offsets=[]
   for text in strings:
    offsets.append(len(payload));v=text.encode('utf-16le');payload+=struct.pack('<H',len(v)//2)+v+b'\0\0'
   payload+=bytes((-len(payload))%4)
   raw=raw[:h];new_start=h+4*count;raw+=struct.pack('<'+'I'*count,*offsets)+payload
   struct.pack_into('<I',raw,4,len(raw));struct.pack_into('<I',raw,20,new_start)
  elif typ==0x102:
   ext=h;_,name,a_start,a_size,count=struct.unpack_from('<IIHHH',raw,ext)
   for i in range(count):
    p=ext+a_start+i*a_size;_,aname,_,_,_,vtype,value=struct.unpack_from('<IIIHBBI',raw,p)
    if strings[name]=='manifest' and strings[aname]=='versionCode':assert vtype==16;struct.pack_into('<I',raw,p+16,283)
  chunks.append(raw);o+=size
 res=bytearray(data[:8])+b''.join(chunks);struct.pack_into('<I',res,4,len(res));return res
buf=io.BytesIO()
with zipfile.ZipFile(base/'Лист-2.7.9.apk') as old,zipfile.ZipFile(buf,'w') as new:
 for source in old.infolist():
  if source.filename.startswith(('META-INF/','assets/web/')):continue
  v=old.read(source)
  if source.filename=='AndroidManifest.xml':v=manifest(v)
  item=zipfile.ZipInfo(source.filename,source.date_time);item.compress_type=source.compress_type;item.external_attr=source.external_attr
  if item.compress_type==zipfile.ZIP_STORED:
   offset=new.fp.tell()+30+len(item.filename.encode());padding=(4-(offset+4)%4)%4;item.extra=struct.pack('<HH',65535,padding)+bytes(padding)
  new.writestr(item,v)
 for p in sorted((root/'web').rglob('*')):
  if p.is_file() and p.name!='ios-entry.html':new.writestr('assets/web/'+p.relative_to(root/'web').as_posix(),p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
(out/'unsigned.apk').write_bytes(buf.getvalue())
with zipfile.ZipFile(base/'Лист-2.7.9.ipa') as old,zipfile.ZipFile(out/'Лист-2.7.12.ipa','w',zipfile.ZIP_DEFLATED) as new:
 for item in old.infolist():
  if item.filename.startswith(('Payload/List.app/web/','Payload/List.app/_CodeSignature/')):continue
  v=old.read(item)
  if item.filename=='Payload/List.app/Info.plist':
   info=plistlib.loads(v);info['CFBundleShortVersionString']='2.7.12';info['CFBundleVersion']='283';v=plistlib.dumps(info)
  new.writestr(item,v)
 for p in sorted((root/'web').rglob('*')):
  if p.is_file():new.writestr('Payload/List.app/web/'+p.relative_to(root/'web').as_posix(),p.read_bytes())
print('Built APK payload and IPA 2.7.12 / 283')
