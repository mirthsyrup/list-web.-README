"""Make an iOS entry page with no external script/style dependencies."""
from pathlib import Path
import re,sys,base64,mimetypes
root=Path(__file__).resolve().parents[1]
web=root/'web'
text=(web/'index.html').read_text()
def inline(match):
    source=(web/match.group(1)).read_text().replace('</script','<\\/script')
    return '<script>'+source+'</script>'
text=re.sub(r'<script src="([^"]+)"></script>',inline,text)
extra=''.join('<script>'+(web/'data'/f'{cat}.js').read_text().replace('</script','<\\/script')+'</script>' for cat in ['feats','spells','actions','conditions'])
text=text.replace('</head>',extra+'</head>')
css=(web/'style.css').read_text()
def inline_asset(match):
    path=web/match.group(1)
    if not path.is_file():raise ValueError('Missing CSS asset: '+str(path))
    return 'url("data:'+mimetypes.guess_type(path)[0]+';base64,'+base64.b64encode(path.read_bytes()).decode()+'")'
css=re.sub(r'url\("([^"]+)"\)',inline_asset,css)
text=text.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
dest=Path(sys.argv[1]);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
print('iOS entry:',dest.stat().st_size,'bytes')
