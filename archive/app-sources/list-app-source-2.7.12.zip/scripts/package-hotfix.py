"""Package version 2.7.8 using the installed 2.7.4 native shells."""
from pathlib import Path
import io,zipfile,struct,plistlib
from repair_android import repair_manifest
root=Path(__file__).resolve().parents[1]
base=root.parent/'downloads'
out=root/'out';out.mkdir(exist_ok=True)
buf=io.BytesIO()
with zipfile.ZipFile(base/'Лист-2.7.8.apk') as old,zipfile.ZipFile(buf,'w') as new:
 for source in old.infolist():
  if source.filename.startswith(('META-INF/','assets/web/')):continue
  payload=old.read(source)
  if source.filename=='AndroidManifest.xml':
   payload,changes=repair_manifest(payload)
   assert payload.count('2.7.8'.encode('utf-16le'))==1
   payload=payload.replace('2.7.8'.encode('utf-16le'),'2.7.9'.encode('utf-16le'))
   print(changes)
  item=zipfile.ZipInfo(source.filename,source.date_time);item.compress_type=source.compress_type;item.external_attr=source.external_attr
  if item.compress_type==zipfile.ZIP_STORED:
   offset=new.fp.tell()+30+len(item.filename.encode());padding=(4-(offset+4)%4)%4;item.extra=struct.pack('<HH',0xffff,padding)+bytes(padding)
  new.writestr(item,payload)
 for path in sorted((root/'web').rglob('*')):
  if path.is_file() and path.name!='ios-entry.html':new.writestr('assets/web/'+path.relative_to(root/'web').as_posix(),path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
(out/'unsigned.apk').write_bytes(buf.getvalue())
buf=io.BytesIO()
with zipfile.ZipFile(base/'Лист-2.7.8.ipa') as old,zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as new:
 for item in old.infolist():
  if item.filename.startswith(('Payload/List.app/web/','Payload/List.app/_CodeSignature/')):continue
  payload=old.read(item)
  if item.filename=='Payload/List.app/Info.plist':
   info=plistlib.loads(payload);info['CFBundleShortVersionString']='2.7.9';info['CFBundleVersion']='280';payload=plistlib.dumps(info)
  new.writestr(item,payload)
 for path in sorted((root/'web').rglob('*')):
  if path.is_file():new.writestr('Payload/List.app/web/'+path.relative_to(root/'web').as_posix(),path.read_bytes())
(out/'Лист-2.7.9.ipa').write_bytes(buf.getvalue())
