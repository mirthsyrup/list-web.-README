const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),R=require('../web/rules-v2.js');
const db={},cats={},ctx={window:{registerCatalog:(k,v)=>{cats[k]=v;for(const x of v)db[x.id]=x}}};
for(const file of fs.readdirSync(path.join(__dirname,'../web/data')).filter(x=>x.endsWith('.js'))){const source=fs.readFileSync(path.join(__dirname,'../web/data',file),'utf8');if(source.startsWith('window.registerCatalog('))vm.runInNewContext(source,ctx);}
test('No visible rule label or prompt leaks a localization key across the offline catalogue',()=>{
 let checked=0;function walk(x){if(Array.isArray(x))return x.forEach(walk);if(!x||typeof x!=='object')return;for(const [key,value]of Object.entries(x)){if(['label','prompt'].includes(key)&&typeof value==='string'){checked++;assert.ok(!/^PF2E\./.test(value),value);}else walk(value);}}walk(cats);assert.ok(checked>1300);
});
test('Specialty Crafting exposes twelve Russian options and preserves a saved raw selection',()=>{
 const feat=cats.feats.find(x=>x.slug==='specialty-crafting');assert.ok(feat);
 const c=R.create();c.feats=[feat.id];let set=R.classChoiceSets(c,db).find(x=>x.sourceId===feat.id);assert.ok(set);assert.equal(set.choices.length,12);
 const names=Array.from(set.choices,x=>x.name);assert.deepEqual(names,['Алхимия','Искусство','Кузнечное дело','Изготовление книг','Стеклоделие','Кожевенное дело','Гончарное дело','Кораблестроение','Камнеобработка','Портняжное дело','Ткачество','Столярное дело']);
 const choice=set.choices.find(x=>x.name==='Кузнечное дело');c.classChoices[set.flag]=choice.id;
 const restored=JSON.parse(JSON.stringify(c));set=R.classChoiceSets(restored,db).find(x=>x.sourceId===feat.id);assert.equal(set.selected,choice.id);assert.equal(set.choices.find(x=>x.id===set.selected).name,'Кузнечное дело');
});
