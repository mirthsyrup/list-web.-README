/* Matched color systems: each accent has its own paper, ink and companion tones. */
(function(root){'use strict';
const roles=['bg','surface','raised','line','text','muted','accent','soft','onAccent','secondary','secondarySoft','tertiary','tertiarySoft'];
const tones=a=>Object.freeze(Object.fromEntries(roles.map((k,i)=>[k,a[i]])));
const palette=(id,name,description,light,dark)=>Object.freeze({id,name,description,light:tones(light),dark:tones(dark)});
const all=[
 palette('rose','Роза','Пыльная роза · шалфей',
 ['#e9ded6','#faf3ed','#e9dbd4','#928187','#3c3035','#574b52','#883950','#f0dfe5','#fff9f7','#2f5647','#e0e9df','#5d4b6c','#e9e1ec'],
 ['#322e32','#454045','#544b51','#a1959d','#f4eeef','#d0c4cc','#f0aec1','#57414c','#34242e','#b8d4bf','#3d4d43','#cdbfe0','#494352']),
 palette('pine','Хвойный','Хвоя · тёплая латунь',
 ['#e3e3d5','#f4f4e9','#dcdfcf','#808d79','#303b32','#4b5748','#245644','#dce9df','#f6fbf7','#614516','#f0e5c8','#425461','#e1e7eb'],
 ['#2b332f','#3c4740','#49564d','#92a495','#eef3e9','#c2cfbf','#abd3b8','#3c5547','#20372a','#e4c58d','#514a37','#b9cedb','#3e4b53']),
 palette('lagoon','Лагуна','Морская зелень · коралл',
 ['#dfe5df','#f0f6ef','#d8e3dc','#7b908c','#2b3b3d','#475755','#20575f','#d7e9e7','#f6fbfa','#794636','#f1e1d6','#44536e','#e2e8f0'],
 ['#293337','#3a474c','#47575e','#91a7ac','#edf2f1','#c2cfd0','#a2d4d5','#365459','#1c363b','#ecc4ad','#55483f','#bdccec','#414c60']),
 palette('berry','Черника','Черника · мягкая медь',
 ['#e5dfe8','#f6f1f7','#e4d9e8','#928098','#38323f','#564a5f','#594880','#e9e0f2','#fdf9ff','#6f482f','#eee1d6','#3c5543','#e0e9df'],
 ['#302e3a','#433f50','#524c61','#a397b7','#f2eef8','#d0c4dd','#cebdf3','#514460','#2e233c','#e8c2a3','#54463d','#b8d0bd','#3f4c45']),
 palette('terracotta','Терракота','Обожжённая глина · нефрит',
 ['#eaded2','#faf2e7','#ead8c9','#968172','#40322d','#5b4a41','#7e4431','#f0dfd4','#fff9f1','#225047','#dce9e2','#4b526e','#e4e6ef'],
 ['#36302d','#4a403a','#5a4d44','#ae9786','#f7eee4','#d6c5b7','#f1b99a','#5d463a','#3c261c','#afd2c2','#3b5046','#c5c9e5','#464958']),
 palette('amber','Янтарь','Мёд · чернильный индиго',
 ['#e9e0cd','#faf5e7','#e8dcc2','#948569','#3d3628','#584e38','#714c16','#f0e4c3','#fffaf0','#3c506b','#e0e7ef','#544e68','#e8e3ed'],
 ['#33312b','#464239','#565044','#a89d83','#f5f0e4','#d3cab5','#e7c486','#594d35','#342916','#b8cde9','#404c60','#cec2e5','#4a4358'])
];
const byId=Object.freeze(Object.assign(Object.create(null),Object.fromEntries(all.map(p=>[p.id,p])))),legacy=Object.freeze(Object.assign(Object.create(null),{pink:'rose',sage:'pine',blue:'lagoon',gold:'amber'}));
function resolve(id){return byId[id]?id:legacy[id]||'rose';}
const rgba=(hex,alpha)=>{const n=parseInt(hex.slice(1),16);return `rgba(${n>>16},${(n>>8)&255},${n&255},${alpha})`;};
function tokens(id,theme){const p=byId[resolve(id)],light=theme==='light',t=p[light?'light':'dark'];return{
 '--bg':t.bg,'--surface':t.surface,'--raised':t.raised,'--line':t.line,'--text':t.text,'--muted':t.muted,
 '--pink':t.accent,'--soft':t.soft,'--on-accent':t.onAccent,'--teal':t.secondary,'--teal-soft':t.secondarySoft,'--lavender':t.tertiary,'--lavender-soft':t.tertiarySoft,
 '--input':light?t.surface:t.bg,'--panel':t.surface,'--nav':rgba(t.surface,.96),'--divider':rgba(t.text,.12),'--border-subtle':rgba(t.text,.17),'--note':rgba(t.text,.045),
 '--paper-wash':rgba(t.bg,light?.90:.92),'--modal-wash':rgba(t.bg,.97),'--glass':rgba(t.surface,.93),'--glass-hp':rgba(light?'#f1e0d6':'#4c3d3b',.95),'--glass-edge':rgba(t.text,.17),'--glass-highlight':light?'rgba(255,255,255,.48)':'rgba(255,255,255,.045)',
 '--accent-edge':rgba(t.accent,.30),'--accent-wash':rgba(t.accent,.07),'--accent-glow':rgba(t.accent,.13),'--secondary-edge':rgba(t.secondary,.28),
 '--green':light?'#326044':'#b2d3ae','--stat-positive':light?'#326044':'#b2d3ae','--stat-negative':light?'#98463d':'#efb2a3',
 '--danger-bg':light?'#f1dcd5':'#553b38','--warning':light?'#765117':'#e7c486','--warning-bg':light?'#f1e5c8':'#4b4233','--health-accent':light?'#914c40':'#edb2a1'
 };}
root.ListPalettes=Object.freeze({all:Object.freeze(all),byId,resolve,tokens});
if(typeof module!=='undefined')module.exports=root.ListPalettes;
})(typeof window!=='undefined'?window:globalThis);
