(function(root){'use strict';
const P=root.ListPalettes;let theme='light',accent='rose';
try{theme=localStorage.getItem('list-theme')==='dark'?'dark':'light';accent=P.resolve(localStorage.getItem('list-accent'));localStorage.setItem('list-theme-release','2.8.6');}catch{}
function apply(){const light=theme==='light',html=document.documentElement;html.dataset.theme=theme;html.dataset.accent=accent;for(const [key,value]of Object.entries(P.tokens(accent,theme)))html.style.setProperty(key,value);if(root.webkit?.messageHandlers?.saveState)html.dataset.nativeIos='true';try{root.NativeBridge?.setTheme?.(theme);root.webkit?.messageHandlers?.setTheme?.postMessage(theme);}catch{}document.querySelector('meta[name="theme-color"]')?.setAttribute('content',P.byId[accent][theme].bg);refreshControls(document);}
function swatches(id){const p=P.byId[id][theme];return `<span class="palette-swatches" aria-hidden="true"><i style="background:${p.surface}"></i><i style="background:${p.accent}"></i><i style="background:${p.secondary}"></i><i style="background:${p.tertiary}"></i></span>`;}
function refreshControls(scope){
 for(const b of scope.querySelectorAll('[data-action="palette-select"]')){const p=P.byId[b.dataset.accent];if(!p)continue;const t=p[theme],on=p.id===accent;b.setAttribute('aria-pressed',String(on));b.classList.toggle('selected',on);for(const [key,value]of Object.entries({bg:t.bg,surface:t.surface,text:t.text,muted:t.muted,accent:t.accent,soft:t.soft,on:t.onAccent}))b.style.setProperty('--preview-'+key,value);for(const [i,key]of ['surface','accent','secondary','tertiary'].entries()){const dot=b.querySelectorAll('.palette-swatches i')[i];if(dot)dot.style.background=t[key];}}
 for(const b of scope.querySelectorAll('[data-action="palette-mode"]')){const on=b.dataset.theme===theme;b.setAttribute('aria-pressed',String(on));b.classList.toggle('on',on);}
 for(const b of scope.querySelectorAll('[data-action="theme-toggle"]')){b.setAttribute('aria-checked',String(theme==='light'));b.querySelector('small').textContent=theme==='light'?'Светлая бумага':'Тёмная фактура';}
 for(const el of scope.querySelectorAll('[data-palette-name]'))el.textContent=P.byId[accent].name;
 for(const el of scope.querySelectorAll('[data-palette-preview]'))el.innerHTML=swatches(accent);
}
apply();
root.ListTheme={
 toggle(){this.setTheme(theme==='light'?'dark':'light');},
 setTheme(value){if(!['light','dark'].includes(value))return false;theme=value;try{localStorage.setItem('list-theme',theme);}catch{}apply();return true;},
 setAccent(id){if(!P.byId[id])return false;accent=id;try{localStorage.setItem('list-accent',accent);}catch{}apply();return true;},
 refreshControls,
 paletteControl(){return `<button class="setting-switch palette-setting" data-action="palette-open"><span><b>Цветовая палитра</b><small data-palette-name>${P.byId[accent].name}</small></span><span data-palette-preview>${swatches(accent)}</span></button>`;},
 palettePicker(){return `<p class="palette-intro">Выбери сочетание для бумаги, карточек и акцентов. Оно сразу применится к сайту.</p><div class="palette-modes chips" role="group" aria-label="Тема палитры">${[['light','Светлая'],['dark','Тёмная']].map(([key,label])=>`<button class="chip ${theme===key?'on':''}" data-action="palette-mode" data-theme="${key}" aria-pressed="${theme===key}">${label}</button>`).join('')}</div><div class="palette-grid" role="group" aria-label="Цветовые палитры">${P.all.map(p=>{const t=p[theme];return `<button class="palette-card ${p.id===accent?'selected':''}" data-action="palette-select" data-accent="${p.id}" aria-pressed="${p.id===accent}" style="--preview-bg:${t.bg};--preview-surface:${t.surface};--preview-text:${t.text};--preview-muted:${t.muted};--preview-accent:${t.accent};--preview-soft:${t.soft};--preview-on:${t.onAccent}"><span class="palette-sample" aria-hidden="true"><span class="palette-sample-page"><span class="palette-sample-lines"><i></i><i></i></span><span class="palette-sample-button"></span></span>${swatches(p.id)}</span><span class="palette-card-label"><b>${p.name}</b><span class="palette-selected-mark" aria-hidden="true">✓</span></span><small>${p.description}</small></button>`;}).join('')}</div>`;},
 control(){return `<button class="setting-switch" data-action="theme-toggle" role="switch" aria-checked="${theme==='light'}"><span><b>Светлая тема</b><small>${theme==='light'?'Светлая бумага':'Тёмная фактура'}</small></span><span class="switch-track"><span></span></span></button>`;}
};
})(window);
