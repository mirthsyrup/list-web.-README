/* Presentation helpers: display source conditions and real calculated differences. */
(function(root){'use strict';
const labels={speed:'Скорость',ac:'КБ',damage:'Урон',attack:'Атаки','attack-roll':'Атаки','skill-check':'Навыки'};
function condition(p,c,R,db){
 if(Array.isArray(p)){const a=p.map(x=>condition(x,c,R,db));return a.every(Boolean)?{text:a.map(x=>x.text).join(' и '),active:a.every(x=>x.active===true)?true:a.some(x=>x.active===false)?false:null}:null;}
 if(typeof p==='string'){
  if(p.startsWith('feature:')){const slug=p.slice(8),feature=Object.values(db).find(f=>f.slug===slug);if(feature)return{text:'с «'+feature.name+'»',active:R.features(c,db).some(f=>f.slug===slug)};}
  if(p==='self:effect:panache')return{text:'при кураже',active:!!c.panache};
  if(['self:shield:raised','self:effect:shield-raised'].includes(p))return{text:'щит поднят',active:!!c.shieldRaised};
  const key=p.replace(/^self:condition:/,'').replace(/^off-guard$/,'offguard');if(p.startsWith('self:condition:')&&R.CONDITIONS[key])return{text:R.CONDITIONS[key][0].toLocaleLowerCase('ru'),active:!!c.conditions[key]};
  return null;
 }
 if(!p||typeof p!=='object')return null;
 if(p.and)return condition(p.and,c,R,db);
 if(p.or){const a=p.or.map(x=>condition(x,c,R,db));return a.every(Boolean)?{text:a.map(x=>x.text).join(' или '),active:a.some(x=>x.active===true)?true:a.every(x=>x.active===false)?false:null}:null;}
 if(p.not){const a=condition(p.not,c,R,db);if(!a)return null;return{text:a.text==='при кураже'?'без куража':'не: '+a.text,active:a.active===null?null:!a.active};}
 return null;
}
function usageHints(c,d,R,db,U){if(!c||!d)return[];const hints=U.usageFields(d).filter(x=>['Требования','Триггер','Частота'].includes(x.label)).map(x=>({...x,active:x.label==='Требования'&&/^(?:у вас (?:есть|имеется) кураж|вы обладаете куражом)[.!]?$/i.test(x.value)?!!c.panache:null}));
 for(const r of d.mechanics?.rules||[]){if(!r.predicate||!['FlatModifier','BaseSpeed'].includes(r.key))continue;const p=condition(r.predicate,c,R,db),selector=Array.isArray(r.selector)?r.selector[0]:r.selector;if(p?.text&&labels[selector])hints.push({label:labels[selector],value:p.text,active:p.active});}
 return hints.filter((x,i,a)=>a.findIndex(y=>y.label===x.label&&y.value===x.value)===i).slice(0,3);
}
function differences(R,before,after,db){const fields=['level','classId','ancestry','heritage','background','key','attributes','skills','feats','inventory','effects','conditions','overrides','classChoices','hp','tempHp','panache','shieldRaised','attacksThisTurn','resources'];if(fields.every(k=>JSON.stringify(before[k])===JSON.stringify(after[k])))return[];const a=R.calculate(before,db),b=R.calculate(after,db),out=[];const add=(key,label,old,value)=>{if(Number.isFinite(old)&&Number.isFinite(value)&&old!==value)out.push({key,label,before:old,after:value,delta:value-old});};
 add('hp','Здоровье',before.hp??a.maxHp,after.hp??b.maxHp);add('tempHp','Временные ОЗ',before.tempHp,after.tempHp);
 for(const [key,label]of [['maxHp','Максимум ОЗ'],['ac','КБ'],['speed','Скорость'],['perception','Восприятие'],['spellDC','КС заклинаний']])add(key,label,a[key],b[key]);
 for(const [key,label]of [['fortitude','Стойкость'],['reflex','Рефлекс'],['will','Воля']])add(key,label,a.saves[key],b.saves[key]);
 for(const item of after.inventory.filter(x=>x.equipped&&db[x.id]?.type==='weapon')){const old=before.inventory.find(x=>x.uid===item.uid&&x.equipped);if(old)add('attack:'+item.uid,db[item.id].name,R.strike(before,old,db).bonus,R.strike(after,item,db).bonus);}
 return out;
}
const api={condition,usageHints,differences};root.ListExperienceTools=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
