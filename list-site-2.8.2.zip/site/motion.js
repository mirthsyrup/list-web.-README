/* Short compositor-only transitions, with no height animation or overshoot. */
(function(root){'use strict';
const reduced=()=>root.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const key=el=>el.dataset.motionKey||el.dataset.journalId||el.dataset.contactId||el.dataset.id||el.id;
function capture(selector,scope=document){if(reduced())return null;const out=new Map();for(const el of scope.querySelectorAll(selector)){const id=key(el),r=el.getBoundingClientRect();if(id&&r.height&&r.bottom>-100&&r.top<root.innerHeight+100)out.set(id,r);}return out;}
function move(before,selector,scope=document){if(!before||reduced())return;for(const el of scope.querySelectorAll(selector)){const old=before.get(key(el));if(!old||!el.animate)continue;for(const a of el.getAnimations())a.cancel();const now=el.getBoundingClientRect(),x=old.left-now.left,y=old.top-now.top;if(Math.abs(x)+Math.abs(y)<1)continue;el.animate([{transform:`translate(${x}px,${y}px)`},{transform:'translate(0,0)'}],{duration:210,easing:'cubic-bezier(.22,1,.36,1)'});}}
function reveal(el){if(reduced()||!el?.animate)return;el.animate([{opacity:.55},{opacity:1}],{duration:160,easing:'ease-out'});}
root.ListMotion={capture,move,reveal,reduced};
})(window);
