/* Read-only catalog exploration. No character or draft is written here. */
(function(root){'use strict';
const TYPES={class:'Класса',ancestry:'Родословной',skill:'Навыка',general:'Общие',archetype:'Архетипа',dedication:'Посвящения'};
const emptyProfile=()=>({ancestry:'',heritage:'',classId:'',background:'',archetype:'',level:1,classChoices:{}});
const emptyFilters=()=>({types:[],rarities:[],min:0,max:20});
function cleanProfile(value={}){const p=emptyProfile();for(const key of ['ancestry','heritage','classId','background','archetype'])if(typeof value[key]==='string')p[key]=value[key].slice(0,100);p.level=Math.max(1,Math.min(20,Number(value.level)||1));if(value.classChoices&&typeof value.classChoices==='object')for(const [key,v]of Object.entries(value.classChoices).slice(0,40))if(typeof v==='string')p.classChoices[key.slice(0,150)]=v.slice(0,200);return p;}
function cleanFilters(value={}){return{types:(Array.isArray(value.types)?value.types:[]).filter(x=>x in TYPES),rarities:(Array.isArray(value.rarities)?value.rarities:[]).filter(x=>['обычный','необычный','редкий','уникальный'].includes(x)),min:Math.max(0,Math.min(20,Number(value.min)||0)),max:Math.max(0,Math.min(20,Number.isFinite(Number(value.max))?Number(value.max):20))};}
const active=p=>!!(p.ancestry||p.classId||p.heritage||p.background||p.archetype);
function character(p,R){const c=R.create();Object.assign(c,{ancestry:p.ancestry,heritage:p.heritage,classId:p.classId,background:p.background,level:p.level,classChoices:{...p.classChoices},feats:[],skills:{}});return c;}
function kinds(d,R){const tags=d.tags||[],out=[];if(d.category==='skill'||tags.includes('skill'))out.push('skill');if(tags.includes('general'))out.push('general');if(d.category==='ancestry')out.push('ancestry');if(R.isArchetype(d))out.push('archetype');else if(d.category==='class')out.push('class');if(tags.includes('dedication'))out.push('dedication');return out;}
function relevant(d,p,db,R){if(!active(p))return true;const cls=db[p.classId],race=db[p.ancestry],tags=d.tags||[];
 if(d.cat==='feats'){
  const groups=R.archetypeData?.members||{},k=kinds(d,R);
  if(k.includes('archetype'))return !!p.archetype&&groups[d.id]===p.archetype;
  if(k.includes('class'))return !!cls&&tags.includes(cls.slug);
  if(k.includes('ancestry'))return !!race&&(tags.includes(race.slug)||tags.includes(db[p.heritage]?.slug));
  return true;
 }
 if(d.cat==='classes')return !cls||d.id===cls.id;
 if(d.cat==='ancestries')return !race||d.id===race.id;
 if(d.cat==='heritages')return p.heritage?d.id===p.heritage:!race||!d.mechanics?.ancestry||d.mechanics.ancestry.slug===race.slug;
 if(d.cat==='backgrounds')return !p.background||d.id===p.background;
 if(['class-features','ancestry-features'].includes(d.cat)){
  const c=character({...p,level:20},R);return R.features(c,db).some(x=>x.id===d.id)||(!cls&&d.cat==='class-features')||(!race&&d.cat==='ancestry-features');
 }
 // Spell traditions and equipment are not inferred from a class name.
 return true;
}
function matches(d,p,f,db,R,{range=true}={}){if(!relevant(d,p,db,R))return false;if(f.types.length&&d.cat==='feats'&&!kinds(d,R).some(k=>f.types.includes(k)))return false;if(f.rarities.length&&!f.rarities.includes(d.rarity||'обычный'))return false;return !range||(d.level||0)>=f.min&&(d.level||0)<=f.max;}
function overview(p,f,db,R,accept=()=>true){const c=character(p,R),auto=R.features(c,db),owned=new Set(auto.map(d=>d.id)),all=R.features(character({...p,level:20},R),db),base=[p.ancestry,p.heritage,p.classId,p.background].map(id=>db[id]).filter(Boolean);
 const available=Object.values(db).filter(d=>d.cat==='feats'&&!owned.has(d.id)&&matches(d,p,f,db,R)&&accept(d));
 const automatic=auto.filter(d=>accept(d));const futureLevels=Object.fromEntries(Object.values(db[p.classId]?.mechanics?.items||{}).map(x=>[x.id,x.level||0]));const futureAuto=all.filter(d=>!owned.has(d.id)&&accept(d)).map(d=>({...d,level:futureLevels[d.id]??d.level}));
 const choices=R.classChoiceSets(c,db);return{c,base,automatic,available:available.filter(d=>d.level<=p.level),future:available.filter(d=>d.level>p.level),futureAutomatic:futureAuto,choices};}
root.ListExplorerModel={TYPES,emptyProfile,emptyFilters,cleanProfile,cleanFilters,active,character,kinds,relevant,matches,overview};
if(typeof module!=='undefined')module.exports=root.ListExplorerModel;
root.ListCatalogExplorer=function(api){const {R,esc,btn,icon,field,option,open,close,render,load,pick,get,db,row,note,empty,matches:searchMatches}=api;const M=root.ListExplorerModel;let state={profile:emptyProfile(),filters:{},view:'overview'};
try{const s=JSON.parse(localStorage.getItem('list-catalog-explorer')||'null');if(s){state.profile=cleanProfile(s.profile);state.view=s.view==='list'?'list':'overview';for(const [k,f]of Object.entries(s.filters||{}))state.filters[k]=cleanFilters(f);}}catch{}
let draft=null,heroQuery='',heroLimit=50;const category=()=>api.category(),filters=()=>state.filters[category()]||emptyFilters(),persist=()=>{try{localStorage.setItem('list-catalog-explorer',JSON.stringify(state));}catch{}};
const selectedName=(id,fallback)=>get(id)?.name||fallback;
const sort=arr=>arr.sort((a,b)=>(a.level||0)-(b.level||0)||a.name.localeCompare(b.name,'ru'));
const archetypes=()=>Object.entries(R.archetypeData?.groups||{}).map(([key,g])=>({key,name:(get(g.dedications[0])?.name||key).replace(/^Посвящение\s+/,'')})).sort((a,b)=>a.name.localeCompare(b.name,'ru'));
const archetypeName=key=>archetypes().find(x=>x.key===key)?.name||'Любой';
const count=()=>filters().types.length+filters().rarities.length+(filters().min>0||filters().max<20?1:0)+(api.edition()!=='all'?1:0);
const selection=(title,key,cat)=>field(title,`<div class="explorer-select-row">${btn(esc(selectedName(draft.profile[key],'Любой вариант'))+icon('chevron'),'explorer-pick',`data-key="${key}" data-cat="${cat}"`,'ghost full')}${draft.profile[key]?btn(icon('close'),'explorer-clear-field',`data-key="${key}" aria-label="Убрать: ${title}"`,'ghost explorer-small'):''}</div>`);
function form(scroll=0){const p=draft.profile,c=character(p,R),choices=R.classChoiceSets(c,db()).map(x=>get(x.sourceId)?.slug==='ancient-elf'?{...x,choices:x.choices.filter(v=>R.archetypeData?.members[v.id]!==get(p.classId)?.slug)}:x);
const options=archetypes();let html=`<p class="subtitle">Изучи сочетание до создания героя. Оно сохраняется отдельно от фильтров справочника.</p><section class="explorer-filter-section"><h3>Изучить сочетание героя</h3>${selection('Родословная','ancestry','ancestries')}${selection('Наследие','heritage','heritages')}${selection('Класс','classId','classes')}`;
if(choices.length)html+=`<div class="explorer-subsection"><h4>Варианты и особенности</h4>${choices.map(x=>field(esc(x.sourceName),`<select data-explorer-choice="${esc(x.flag)}" aria-label="${esc(x.sourceName)}">${option([['','Не уточнять'],...x.choices.map(v=>[v.id,v.name])],p.classChoices[x.flag]||'')}</select>`)).join('')}</div>`;
html+=selection('Предыстория · необязательно','background','backgrounds')+field('Архетип · необязательно',`<select id="explorer-archetype">${option([['','Без архетипа'],...options.map(x=>[x.key,x.name])],p.archetype)}</select>`)+field('Уровень просмотра',`<select id="explorer-level">${option(Array.from({length:20},(_,i)=>[String(i+1),String(i+1)]),String(p.level))}</select>`)+`</section>`;if(draft.mode==='hero'){open('Сочетание героя',html,btn('Сбросить сочетание','explorer-reset','','ghost')+btn('Возможности героя','explorer-apply','','primary'),'catalog-explorer');document.querySelector('.modal').scrollTop=scroll;return;}html=btn('Изучить сочетание героя','explorer-profile','','ghost full')+`<section class="explorer-filter-section"><h3>Сузить список</h3>`+field('Издание',`<select id="explorer-edition">${option([['all','Все издания'],['remaster','Ремастер'],['legacy','Ранние издания'],['avessalom','Авессалом']],draft.edition)}</select>`);
if(category()==='feats')html+=`<h4>Тип способности</h4><div class="explorer-checks">${Object.entries(TYPES).map(([key,label])=>`<label><input type="checkbox" data-explorer-type="${key}" ${draft.filters.types.includes(key)?'checked':''}>${label}</label>`).join('')}</div>`;
html+=`<h4>Редкость</h4><div class="explorer-checks">${['обычный','необычный','редкий','уникальный'].map(r=>`<label><input type="checkbox" data-explorer-rarity="${r}" ${draft.filters.rarities.includes(r)?'checked':''}>${r[0].toUpperCase()+r.slice(1)}</label>`).join('')}</div><div class="grid two">${field(category()==='spells'?'Ранг от':'Уровень от',`<input id="explorer-min" type="number" min="0" max="20" value="${draft.filters.min}">`)}${field(category()==='spells'?'Ранг до':'Уровень до',`<input id="explorer-max" type="number" min="0" max="20" value="${draft.filters.max}">`)}</div></section>`;
open('Фильтр',html,btn('Сбросить','explorer-reset','','ghost')+btn('Показать','explorer-apply','','primary'),'catalog-explorer');document.querySelector('.modal').scrollTop=scroll;updateCount();}
function acceptEdition(d,edition){return edition==='all'||(edition==='avessalom'?root.AVESSALOM_SOURCES?.ids.includes(d.id):d.remaster===(edition==='remaster'));}
function updateCount(){if(!draft||draft.mode==='hero')return;const arr=root.CATALOG[category()]||[],n=arr.filter(d=>M.matches(d,emptyProfile(),draft.filters,db(),R)&&acceptEdition(d,draft.edition)&&searchMatches(d,api.query())).length;const button=document.querySelector('[data-action="explorer-apply"]');if(button)button.textContent='Показать · '+n.toLocaleString('ru');}
function changed(e){if(!draft)return;const el=e.target;let refresh=false;
if(el.dataset.explorerChoice!==undefined){if(el.value)draft.profile.classChoices[el.dataset.explorerChoice]=el.value;else delete draft.profile.classChoices[el.dataset.explorerChoice];refresh=true;}
if(el.id==='explorer-level'){draft.profile.level=Number(el.value);refresh=true;}
if(el.id==='explorer-archetype')draft.profile.archetype=el.value;
if(el.id==='explorer-edition')draft.edition=el.value;
for(const [attr,key]of [['explorerType','types'],['explorerRarity','rarities']])if(el.dataset[attr])draft.filters[key]=el.checked?[...new Set([...draft.filters[key],el.dataset[attr]])]:draft.filters[key].filter(x=>x!==el.dataset[attr]);
if(el.id==='explorer-min'||el.id==='explorer-max')draft.filters[el.id==='explorer-min'?'min':'max']=Math.max(0,Math.min(20,Number(el.value)||0));
if(refresh)form(document.querySelector('.modal')?.scrollTop||0);else updateCount();}
document.addEventListener('change',changed);document.addEventListener('input',e=>{if(e.target.id==='explorer-min'||e.target.id==='explorer-max')changed(e);});
function toolbar(){const parts=[];for(const key of filters().types)parts.push({key:'type:'+key,text:TYPES[key]});for(const rarity of filters().rarities)parts.push({key:'rarity:'+rarity,text:rarity});if(filters().min>0||filters().max<20)parts.push({key:'range',text:filters().min+'–'+filters().max+' уровень'});
return `<div class="explorer-summary">${parts.map(x=>`<button class="chip" data-action="explorer-remove" data-key="${esc(x.key)}" aria-label="Убрать условие: ${esc(x.text)}">${esc(x.text)}${icon('close')}</button>`).join('')}${parts.length?btn('Сбросить фильтры','explorer-clear','','linkbtn'):''}</div>${active(state.profile)?btn('Возможности героя','explorer-hero','','ghost full explorer-hero-link'):''}`;}
function section(title,arr,key,{future=false}={}){if(!arr.length)return '';const n=heroLimit,items=sort(arr).slice(0,n);return `<section class="explorer-results"><div class="section"><h2>${title}</h2><span class="count">${arr.length}</span></div>${items.map(d=>`<div class="explorer-record">${row(d)}${d.cat==='feats'?`<small class="explorer-record-meta">${esc(kinds(d,R).map(k=>TYPES[k]).join(' · '))}${future?' · '+d.level+' уровень':''}${d.prereq?' · Условия: '+esc(d.prereq):''}</small>`:''}</div>`).join('')}${arr.length>n?btn('Показать ещё','explorer-more','','ghost full'):''}</section>`;}
function results(){if(!active(state.profile))return empty('Выбери сочетание героя.');const p=state.profile,f=emptyFilters(),result=M.overview(p,f,db(),R,d=>searchMatches(d,heroQuery));const missing=result.choices.filter(x=>!x.selected);
let html=`<div class="explorer-intro"><p>Обзор на ${p.level}-м уровне. Подходящие способности показаны для изучения: их нельзя получить все одновременно.</p></div>`;
if(!heroQuery)html+=`<div class="explorer-base">${result.base.map(d=>row(d)).join('')}</div>`;
if(missing.length&&!heroQuery)html+=note('Можно уточнить в фильтре: '+missing.map(x=>esc(x.sourceName)).join(', ')+'. Зависимые возможности появятся после выбора варианта.');
const grouped=(title,arr,future=false)=>{if(!arr.length)return '';const groups=new Map();for(const d of arr){const ks=kinds(d,R),kind=ks.includes('archetype')?'archetype':ks.includes('class')?'class':ks.includes('ancestry')?'ancestry':ks.includes('skill')?'skill':ks.includes('general')?'general':'other';if(!groups.has(kind))groups.set(kind,[]);groups.get(kind).push(d);}return `<div class="section"><h2>${title}</h2></div>`+[...groups].sort(([a],[b])=>['class','ancestry','archetype','skill','general','other'].indexOf(a)-['class','ancestry','archetype','skill','general','other'].indexOf(b)).map(([kind,items])=>section(TYPES[kind]||'Другие способности',items,kind,{future})).join('');};
html+=section('Получаешь автоматически',result.automatic,'auto')+grouped('Можешь выбрать',result.available)+section('На следующих уровнях · автоматически',result.futureAutomatic,'future-auto',{future:true})+grouped('На следующих уровнях · на выбор',result.future,true);
if(!result.automatic.length&&!result.available.length&&!result.future.length&&!result.futureAutomatic.length)html+=empty('По этим условиям ничего не найдено. Измени поиск или фильтр.');
return html;}
function hero(scroll=0){open('Возможности героя',`<div class="search catalog-search"><input id="explorer-search" aria-label="Поиск в возможностях героя" value="${esc(heroQuery)}" placeholder="Найти возможность…" autocomplete="off"><button class="search-clear" id="explorer-search-clear" data-action="explorer-search-clear" aria-label="Очистить поиск возможностей" ${heroQuery?'':'hidden'}>${icon('close')}</button></div>${btn('Изменить сочетание','explorer-profile','','ghost full')}<div id="explorer-results">${results()}</div>`,'','hero-overview');document.querySelector('.modal').classList.add('hero-overview');document.querySelector('.backdrop').classList.add('hero-backdrop');document.querySelector('.modal').scrollTop=scroll;}
document.addEventListener('input',e=>{if(e.target.id!=='explorer-search')return;heroQuery=e.target.value;heroLimit=50;document.querySelector('#explorer-results').innerHTML=results();document.querySelector('#explorer-search-clear').hidden=!heroQuery;});
async function handle(action,data){if(!action.startsWith('explorer-'))return false;
if(action==='explorer-open'||action==='explorer-profile'){await Promise.all(['feats','class-features','ancestry-features'].map(load));draft={mode:action==='explorer-profile'?'hero':'filter',profile:cleanProfile(state.profile),filters:cleanFilters(filters()),edition:api.edition()};form();}
else if(action==='explorer-hero'){await Promise.all(['feats','class-features','ancestry-features'].map(load));hero();}
else if(action==='explorer-pick'){const key=data.key;await pick(data.cat,id=>{draft.profile[key]=id;if(key==='ancestry'){draft.profile.heritage='';draft.profile.classChoices={};}if(key==='classId'||key==='heritage')draft.profile.classChoices={};form();},{title:({ancestry:'Родословная',heritage:'Наследие',classId:'Класс',background:'Предыстория'})[key],predicate:d=>key!=='heritage'||!draft.profile.ancestry||!d.mechanics?.ancestry||d.mechanics.ancestry.slug===get(draft.profile.ancestry)?.slug});}
else if(action==='explorer-clear-field'){draft.profile[data.key]='';if(data.key==='ancestry')draft.profile.heritage='';if(['ancestry','heritage','classId'].includes(data.key))draft.profile.classChoices={};form();}
else if(action==='explorer-reset'){draft=draft.mode==='hero'?{...draft,profile:emptyProfile()}:{...draft,filters:emptyFilters(),edition:'all'};form();}
else if(action==='explorer-apply'){if(draft.mode==='hero'){if(!active(draft.profile)){api.toast('Выбери хотя бы родословную, класс или другой вариант.');return true;}state.profile=cleanProfile(draft.profile);persist();draft=null;heroQuery='';heroLimit=50;close();render();hero();}else{if(draft.filters.min>draft.filters.max){api.toast('Начало диапазона должно быть не больше конца.');return true;}state.filters[category()]=cleanFilters(draft.filters);api.setEdition(draft.edition);persist();draft=null;close();render();api.remember();}}
else if(action==='explorer-more'){const scroll=document.querySelector('.modal').scrollTop;heroLimit+=50;document.querySelector('#explorer-results').innerHTML=results();document.querySelector('.modal').scrollTop=scroll;}
else if(action==='explorer-search-clear'){heroQuery='';heroLimit=50;document.querySelector('#explorer-search').value='';document.querySelector('#explorer-search-clear').hidden=true;document.querySelector('#explorer-results').innerHTML=results();document.querySelector('#explorer-search').focus({preventScroll:true});}
else if(action==='explorer-clear'){state.filters[category()]=emptyFilters();api.setEdition('all');persist();render();api.remember();}
else if(action==='explorer-remove'){const key=data.key;if(key.startsWith('type:'))state.filters[category()]={...filters(),types:filters().types.filter(x=>x!==key.slice(5))};else if(key.startsWith('rarity:'))state.filters[category()]={...filters(),rarities:filters().rarities.filter(x=>x!==key.slice(7))};else if(key==='range')state.filters[category()]={...filters(),min:0,max:20};persist();render();api.remember();}
return true;}
return{toolbar,results:()=>null,handle,count,filter:d=>M.matches(d,emptyProfile(),filters(),db(),R)};
};
})(typeof window!=='undefined'?window:globalThis);
